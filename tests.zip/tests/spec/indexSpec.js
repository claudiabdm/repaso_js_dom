describe("index.js", function () {

  beforeEach(function () {
    // document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
  })
  it("should remove all li before paint", function () {
    const dummyElement = document.createElement('div');
    dummyElement.innerHTML = `
    <div class="wrapper-list">
      <ul class="todo-list" id="list">
        <li>hola, un li de ejemplo</li>
      </ul>
    </div>`;

    const tasks = [];

    pintar(dummyElement, tasks);

    debugger
  })
  it("should paint all data in array", function () {

  })
})